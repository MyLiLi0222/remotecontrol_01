﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 RemoteClient.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_REMOTECLIENT_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_MENU_RCLICK                 130
#define IDD_DLG_STATUS                  131
#define IDD_DLG_WATCH                   133
#define IDC_BTN_TEST                    1000
#define IDC_EDIT_PORT                   1001
#define IDC_IPADDRESS_SERV              1002
#define IDC_TREE_DIR                    1005
#define IDC_LIST_FILE                   1006
#define IDC_BUTTON_FILEINFO             1007
#define IDC_EDIT_INFO                   1009
#define IDC_BTN_START_WATCH             1010
#define IDC_WATCH                       1011
#define IDC_BTN_LOCK                    1013
#define IDC_BUTTON3                     1014
#define IDC_BTN_UNLOCK                  1014
#define ID_32771                        32771
#define ID_32772                        32772
#define ID_32773                        32773
#define ID_                             32774
#define ID_DownloadFIle                 32775
#define ID_DeleteFile                   32776
#define ID_OpenFile                     32777

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
